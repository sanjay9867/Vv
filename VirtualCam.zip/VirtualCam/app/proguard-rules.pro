# Keep Xposed hook entry point
-keep class com.example.virtualcam.hook.** { *; }
