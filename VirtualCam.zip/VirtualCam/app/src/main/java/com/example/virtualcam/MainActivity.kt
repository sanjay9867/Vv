package com.example.virtualcam

import android.content.Context
import android.os.Bundle
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButton
import com.google.android.material.materialswitch.MaterialSwitch
import java.io.File

class MainActivity : AppCompatActivity() {

    private lateinit var statusText: TextView

    private val pickVideoLauncher =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) {
                val dest = File(filesDir, VirtualCamProvider.VIDEO_FILENAME)
                contentResolver.openInputStream(uri)?.use { input ->
                    dest.outputStream().use { output -> input.copyTo(output) }
                }
                statusText.text = "Video loaded (${dest.length() / 1024} KB)"
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val prefs = getSharedPreferences("vcam_prefs", Context.MODE_PRIVATE)

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(56, 96, 56, 56)
        }

        val title = TextView(this).apply {
            text = "VirtualCam (LSPatch Module)"
            textSize = 22f
            setPadding(0, 0, 0, 32)
        }

        val toggle = MaterialSwitch(this).apply {
            text = "Enable Virtual Camera"
            isChecked = prefs.getBoolean(VirtualCamProvider.KEY_ENABLED, false)
            setOnCheckedChangeListener { _, checked ->
                prefs.edit().putBoolean(VirtualCamProvider.KEY_ENABLED, checked).apply()
            }
        }

        val pickBtn = MaterialButton(this).apply {
            text = "Select MP4 Video"
            setOnClickListener { pickVideoLauncher.launch(arrayOf("video/mp4")) }
        }

        statusText = TextView(this).apply {
            val file = File(filesDir, VirtualCamProvider.VIDEO_FILENAME)
            text = if (file.exists()) {
                "Video ready (${file.length() / 1024} KB)"
            } else {
                "No video selected yet"
            }
            setPadding(0, 24, 0, 32)
        }

        val helpText = TextView(this).apply {
            text = "Setup:\n1. Select a short H.264 MP4 video and turn on the switch.\n" +
                "2. Patch your target app in LSPatch Manager.\n" +
                "3. Enable VirtualCam in that patched app's module scope."
            textSize = 14f
        }

        layout.addView(title)
        layout.addView(toggle)
        layout.addView(pickBtn)
        layout.addView(statusText)
        layout.addView(helpText)
        setContentView(layout)
    }
}
