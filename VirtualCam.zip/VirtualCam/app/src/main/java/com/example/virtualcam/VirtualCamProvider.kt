package com.example.virtualcam

import android.content.ContentProvider
import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.net.Uri
import android.os.Bundle
import android.os.ParcelFileDescriptor
import java.io.File
import java.io.FileNotFoundException

class VirtualCamProvider : ContentProvider() {

    companion object {
        const val AUTHORITY = "com.example.virtualcam.provider"
        val VIDEO_URI: Uri = Uri.parse("content://$AUTHORITY/video")
        const val METHOD_IS_ENABLED = "is_enabled"
        const val KEY_ENABLED = "enabled"
        const val VIDEO_FILENAME = "virtual_cam.mp4"
    }

    override fun onCreate(): Boolean = true

    override fun openFile(uri: Uri, mode: String): ParcelFileDescriptor {
        val ctx = context ?: throw FileNotFoundException("Context unavailable")
        val file = File(ctx.filesDir, VIDEO_FILENAME)
        if (!file.exists()) {
            throw FileNotFoundException("No virtual camera video selected")
        }
        return ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY)
    }

    override fun call(method: String, arg: String?, extras: Bundle?): Bundle? {
        if (method == METHOD_IS_ENABLED) {
            val prefs = context?.getSharedPreferences("vcam_prefs", Context.MODE_PRIVATE)
            val enabled = prefs?.getBoolean(KEY_ENABLED, false) ?: false
            return Bundle().apply { putBoolean(KEY_ENABLED, enabled) }
        }
        return null
    }

    override fun query(
        uri: Uri,
        projection: Array<out String>?,
        selection: String?,
        selectionArgs: Array<out String>?,
        sortOrder: String?
    ): Cursor? = null

    override fun getType(uri: Uri): String = "video/mp4"

    override fun insert(uri: Uri, values: ContentValues?): Uri? = null

    override fun delete(uri: Uri, selection: String?, selectionArgs: Array<out String>?): Int = 0

    override fun update(
        uri: Uri,
        values: ContentValues?,
        selection: String?,
        selectionArgs: Array<out String>?
    ): Int = 0
}
