package com.example.virtualcam.hook

import android.app.Application
import android.content.Context
import android.graphics.SurfaceTexture
import android.hardware.camera2.CameraCaptureSession
import android.hardware.camera2.CaptureRequest
import android.hardware.camera2.params.OutputConfiguration
import android.hardware.camera2.params.SessionConfiguration
import android.media.MediaPlayer
import android.os.Handler
import android.view.Surface
import com.example.virtualcam.VirtualCamProvider
import de.robv.android.xposed.IXposedHookLoadPackage
import de.robv.android.xposed.XC_MethodHook
import de.robv.android.xposed.XposedBridge
import de.robv.android.xposed.XposedHelpers
import de.robv.android.xposed.callbacks.XC_LoadPackage
import java.util.concurrent.CopyOnWriteArrayList

class VirtualCamHook : IXposedHookLoadPackage {

    @Volatile
    private var appContext: Context? = null

    private var dummyTexture: SurfaceTexture? = null
    private var dummySurface: Surface? = null
    private val activePlayers = CopyOnWriteArrayList<MediaPlayer>()
    private val interceptedSurfaces = CopyOnWriteArrayList<Surface>()

    override fun handleLoadPackage(lpparam: XC_LoadPackage.LoadPackageParam) {
        if (lpparam.packageName == "com.example.virtualcam") return

        // 1. Capture target app Context
        XposedHelpers.findAndHookMethod(
            Application::class.java,
            "onCreate",
            object : XC_MethodHook() {
                override fun afterHookedMethod(param: MethodHookParam) {
                    appContext = (param.thisObject as Application).applicationContext
                }
            }
        )

        // 2. Intercept CaptureRequest.Builder.addTarget(Surface)
        XposedHelpers.findAndHookMethod(
            CaptureRequest.Builder::class.java,
            "addTarget",
            Surface::class.java,
            object : XC_MethodHook() {
                override fun beforeHookedMethod(param: MethodHookParam) {
                    if (!isVirtualCamEnabled()) return
                    val originalSurface = param.args[0] as? Surface ?: return
                    if (originalSurface == dummySurface) return

                    if (!interceptedSurfaces.contains(originalSurface)) {
                        interceptedSurfaces.add(originalSurface)
                    }
                    param.args[0] = getOrCreateDummySurface()
                }
            }
        )

        val cameraDeviceImplClass = XposedHelpers.findClassIfExists(
            "android.hardware.camera2.impl.CameraDeviceImpl",
            lpparam.classLoader
        ) ?: return

        // 3a. Modern Camera2 / CameraX path (Android 9+)
        XposedHelpers.findAndHookMethod(
            cameraDeviceImplClass,
            "createCaptureSession",
            SessionConfiguration::class.java,
            object : XC_MethodHook() {
                override fun beforeHookedMethod(param: MethodHookParam) {
                    if (!isVirtualCamEnabled()) return
                    val origConfig = param.args[0] as? SessionConfiguration ?: return

                    val realSurfaces = origConfig.outputConfigurations.mapNotNull { it.surface }
                    if (realSurfaces.isEmpty()) return

                    val dummy = getOrCreateDummySurface()
                    val fakeConfig = SessionConfiguration(
                        origConfig.sessionType,
                        listOf(OutputConfiguration(dummy)),
                        origConfig.executor,
                        origConfig.stateCallback
                    )
                    param.args[0] = fakeConfig

                    startPlaybackOnSurfaces(realSurfaces)
                }
            }
        )

        // 3b. Legacy Camera2 path
        XposedHelpers.findAndHookMethod(
            cameraDeviceImplClass,
            "createCaptureSession",
            List::class.java,
            CameraCaptureSession.StateCallback::class.java,
            Handler::class.java,
            object : XC_MethodHook() {
                @Suppress("UNCHECKED_CAST")
                override fun beforeHookedMethod(param: MethodHookParam) {
                    if (!isVirtualCamEnabled()) return
                    val origSurfaces = (param.args[0] as? List<Surface>) ?: return
                    if (origSurfaces.isEmpty()) return

                    param.args[0] = listOf(getOrCreateDummySurface())
                    startPlaybackOnSurfaces(origSurfaces)
                }
            }
        )

        // 4. Clean up players when the camera closes
        XposedHelpers.findAndHookMethod(
            cameraDeviceImplClass,
            "close",
            object : XC_MethodHook() {
                override fun beforeHookedMethod(param: MethodHookParam) {
                    releaseAllPlayers()
                }
            }
        )
    }

    private fun isVirtualCamEnabled(): Boolean {
        val ctx = appContext ?: return false
        return try {
            val result = ctx.contentResolver.call(
                VirtualCamProvider.VIDEO_URI,
                VirtualCamProvider.METHOD_IS_ENABLED,
                null,
                null
            )
            result?.getBoolean(VirtualCamProvider.KEY_ENABLED, false) ?: false
        } catch (e: Exception) {
            false
        }
    }

    @Synchronized
    private fun getOrCreateDummySurface(): Surface {
        if (dummySurface == null || dummySurface?.isValid == false) {
            dummyTexture = SurfaceTexture(0).apply { setDefaultBufferSize(640, 480) }
            dummySurface = Surface(dummyTexture)
        }
        return dummySurface!!
    }

    private fun startPlaybackOnSurfaces(surfaces: List<Surface>) {
        val ctx = appContext ?: return
        releaseAllPlayers()

        for (surface in surfaces) {
            if (!surface.isValid) continue
            if (surface.toString().contains("ImageReader", ignoreCase = true)) continue

            try {
                val pfd = ctx.contentResolver.openFileDescriptor(VirtualCamProvider.VIDEO_URI, "r")
                    ?: continue

                val player = MediaPlayer().apply {
                    setSurface(surface)
                    setVolume(0f, 0f)
                    isLooping = true
                    pfd.use { setDataSource(it.fileDescriptor) }
                    setOnPreparedListener { it.start() }
                    setOnErrorListener { mp, what, extra ->
                        XposedBridge.log("VirtualCam MediaPlayer error: $what/$extra")
                        mp.release()
                        true
                    }
                    prepareAsync()
                }
                activePlayers.add(player)
            } catch (e: Exception) {
                XposedBridge.log("VirtualCam failed on surface: ${e.message}")
            }
        }
    }

    private fun releaseAllPlayers() {
        for (player in activePlayers) {
            try {
                if (player.isPlaying) player.stop()
                player.release()
            } catch (_: Exception) {
            }
        }
        activePlayers.clear()
        interceptedSurfaces.clear()
    }
}
